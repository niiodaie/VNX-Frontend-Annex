import React, { useState } from 'react';
import { useProjectPlanAI } from '../hooks/useProjectPlanAI';

export default function TryOncePlanner() {
  const { generatePlan, loading } = useProjectPlanAI();
  const [description, setDescription] = useState('');
  const [plan, setPlan] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    setSubmitted(true);
    const result = await generatePlan(description);
    setPlan(result);
  };

  return (
    <div className="bg-white shadow-md p-6 rounded-md mt-6">
      <h2 className="text-xl font-bold mb-4">Try Project Planning (Free Demo)</h2>
      <textarea
        className="w-full border p-2 rounded mb-4"
        rows="3"
        placeholder="Describe your project (e.g., Launch a podcast)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <button
        onClick={handleSubmit}
        disabled={loading || submitted}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {loading ? 'Generating...' : submitted ? 'Submitted' : 'Generate Plan'}
      </button>

      {plan && (
        <div className="mt-6 border-t pt-4">
          <h3 className="font-semibold text-lg mb-2">AI-Generated Plan</h3>
          {plan.map((milestone, idx) => (
            <div key={idx} className="mb-4">
              <h4 className="font-bold">{milestone.title}</h4>
              <ul className="list-disc list-inside">
                {milestone.tasks.map((task, i) => (
                  <li key={i}>{task}</li>
                ))}
              </ul>
            </div>
          ))}
          <div className="mt-4 text-center text-sm text-gray-500">
            Upgrade to Premium to save or customize your plan.
          </div>
        </div>
      )}
    </div>
  );
}
