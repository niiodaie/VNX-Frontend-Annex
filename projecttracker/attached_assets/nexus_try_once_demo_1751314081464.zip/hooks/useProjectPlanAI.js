import { useState } from 'react';

export function useProjectPlanAI() {
  const [loading, setLoading] = useState(false);

  const generatePlan = async (description) => {
    setLoading(true);
    await new Promise((res) => setTimeout(res, 1000)); // simulate delay
    const fakePlan = [
      {
        title: "Kickoff Phase",
        tasks: ["Define goals", "Identify stakeholders", "Initial team meeting"]
      },
      {
        title: "Execution",
        tasks: ["Create content", "Schedule recordings", "Market launch"]
      }
    ];
    setLoading(false);
    return fakePlan;
  };

  return { generatePlan, loading };
}
