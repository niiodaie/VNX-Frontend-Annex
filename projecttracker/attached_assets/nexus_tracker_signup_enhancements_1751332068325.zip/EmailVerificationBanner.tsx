import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function EmailVerificationBanner() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user && !user.email_confirmed_at) setShowBanner(true);
    })();
  }, []);

  if (!showBanner) return null;

  return (
    <div className="bg-yellow-100 p-2 text-yellow-900 text-center">
      Please verify your email to access all features.
    </div>
  );
}
