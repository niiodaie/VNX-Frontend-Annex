import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function AdminUserPanel() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, display_name, role, created_at');
      if (!error) setUsers(data);
    })();
  }, []);

  return (
    <table>
      <thead><tr><th>Name</th><th>Role</th><th>Created</th></tr></thead>
      <tbody>
        {users.map(u => (
          <tr key={u.id}><td>{u.display_name}</td><td>{u.role}</td><td>{u.created_at}</td></tr>
        ))}
      </tbody>
    </table>
  );
}
