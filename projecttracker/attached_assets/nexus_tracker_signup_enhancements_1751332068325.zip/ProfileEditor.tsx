import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import toast from 'react-hot-toast';

export default function ProfileEditor({ userId }) {
  const [name, setName] = useState('');

  const updateProfile = async () => {
    const { error } = await supabase
      .from('profiles')
      .update({ display_name: name })
      .eq('id', userId);

    if (!error) toast.success('Profile updated');
    else toast.error(error.message);
  };

  return (
    <div>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Display Name" />
      <button onClick={updateProfile}>Update Profile</button>
    </div>
  );
}
