import { supabase } from '@/lib/supabase';
import toast from 'react-hot-toast';
import { useRouter } from 'next/router';

export const handleSignup = async (email: string, password: string) => {
  const router = useRouter();
  const { data, error } = await supabase.auth.signUp({ email, password });

  if (error) return toast.error(error.message);
  toast.success('Account created! Check your inbox to verify.');

  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (profile?.role === 'admin') router.push('/dashboard/admin');
  else if (profile?.role === 'super_admin') router.push('/dashboard/super');
  else router.push('/dashboard/user');
};
