
import React from 'react';

const Pricing = () => {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold mb-4">Choose Your Plan</h1>
      <p className="text-gray-600 mb-6">Flexible pricing for solopreneurs and teams.</p>

      <div className="grid md:grid-cols-3 gap-6">
        {[
          { title: 'Free', price: '$0/mo', features: ['2 Projects', 'Basic To-dos'] },
          { title: 'Pro', price: '$9/mo', features: ['Unlimited Projects', 'AI Prompt Recall', 'Reminders'] },
          { title: 'Team', price: '$29/mo', features: ['All Pro features', 'Shared Boards', 'Export/Backup'] },
        ].map(plan => (
          <div key={plan.title} className="border rounded-lg shadow p-4">
            <h2 className="text-xl font-bold">{plan.title}</h2>
            <p className="text-lg text-gray-700">{plan.price}</p>
            <ul className="text-sm mt-3 space-y-1">
              {plan.features.map((f, idx) => (
                <li key={idx}>✔ {f}</li>
              ))}
            </ul>
            <button className="mt-4 bg-blue-600 hover:bg-blue-700 text-white py-1 px-4 rounded">Get Started</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;
