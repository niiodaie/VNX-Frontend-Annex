
import { useAuth } from './AuthProvider';
import { supabase } from '../services/supabaseClient';

const Header = () => {
  const { user, setUser } = useAuth();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    window.location.href = '/';
  };

  return (
    <header className="flex justify-between p-4 border-b">
      <h1 className="text-xl font-bold">Nexus Tracker</h1>
      <div className="space-x-4">
        {user ? (
          <>
            <span className="text-sm text-gray-700">👤 {user.email}</span>
            <button onClick={handleLogout} className="text-red-500">Sign Out</button>
          </>
        ) : (
          <>
            <a href="/login" className="text-blue-600">Login</a>
            <a href="/signup" className="text-green-600">Sign Up</a>
          </>
        )}
      </div>
    </header>
  );
};

export default Header;
