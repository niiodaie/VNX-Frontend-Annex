import React, { useEffect, useState } from 'react';
import { supabase } from '../../utils/supabaseClient';

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchProjects();
  }, []);

  async function fetchProjects() {
    const { data, error } = await supabase.from('projects').select('*');
    if (error) {
      console.error("Error fetching projects:", error.message);
    } else {
      setProjects(data);
    }
  }

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Projects</h1>
      <input
        type="text"
        placeholder="Search projects..."
        className="mb-4 p-2 border rounded w-full max-w-md"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProjects.map((project) => (
          <div key={project.id} className="p-4 border rounded shadow bg-white">
            <h2 className="text-xl font-semibold">{project.name}</h2>
            <p className="text-gray-600">{project.description}</p>
            <p className="text-sm text-gray-500 mt-2">Status: {project.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
}