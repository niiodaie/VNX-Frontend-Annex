
import { useState, useEffect } from 'react'
import { getUsers, updateUserRole, deleteUser } from '@/lib/supabase-admin'
import { Badge, Button, Select, Table, Toast } from '@/components/ui'
import { Crown, Shield, Trash } from 'lucide-react'

export default function AdminUserPanel() {
  const [users, setUsers] = useState([])
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({})

  useEffect(() => {
    async function fetchUsers() {
      setLoading(true)
      const { data } = await getUsers()
      setUsers(data)
      const roleStats = data.reduce((acc, u) => {
        acc[u.role] = (acc[u.role] || 0) + 1
        return acc
      }, {})
      setStats(roleStats)
      setLoading(false)
    }
    fetchUsers()
  }, [])

  const filteredUsers = users.filter(u =>
    (filter === 'all' || u.role === filter) &&
    (u.display_name.toLowerCase().includes(search.toLowerCase()))
  )

  const handleRoleChange = async (id, newRole) => {
    await updateUserRole(id, newRole)
    Toast.success('Role updated')
    setUsers(users.map(u => (u.id === id ? { ...u, role: newRole } : u)))
  }

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this user?')) return
    await deleteUser(id)
    Toast.success('User deleted')
    setUsers(users.filter(u => u.id !== id))
  }

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Admin User Panel</h2>
      <div className="flex gap-2 mb-2">
        <input
          className="input"
          placeholder="Search users"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select onChange={(e) => setFilter(e.target.value)} value={filter}>
          <option value="all">All Roles</option>
          <option value="super_admin">Super Admin</option>
          <option value="admin">Admin</option>
          <option value="moderator">Moderator</option>
          <option value="user">User</option>
        </Select>
      </div>
      <Table>
        <thead>
          <tr><th>Name</th><th>Role</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {filteredUsers.map(user => (
            <tr key={user.id}>
              <td>{user.display_name}</td>
              <td>
                <Badge>{user.role}</Badge>
                {user.role === 'super_admin' && <Crown className="inline ml-1" />}
                {user.role === 'admin' && <Shield className="inline ml-1" />}
              </td>
              <td>
                <Select value={user.role} onChange={(e) => handleRoleChange(user.id, e.target.value)}>
                  <option value="user">User</option>
                  <option value="moderator">Moderator</option>
                  <option value="admin">Admin</option>
                  <option value="super_admin">Super Admin</option>
                </Select>
                <Button onClick={() => handleDelete(user.id)}><Trash /></Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div className="mt-4">
        <strong>Total Users:</strong> {users.length} <br/>
        <strong>By Role:</strong> {JSON.stringify(stats)}
      </div>
    </div>
  )
}
