import { useState } from 'react';

export function useProjectPlanAI() {
  const [loading, setLoading] = useState(false);

  const generatePlan = async (description, tone = "concise", taskCount = 5) => {
    setLoading(true);
    const res = await fetch('/api/plan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ description, tone, taskCount })
    });

    const data = await res.json();
    setLoading(false);
    return data;
  };

  return { generatePlan, loading };
}
