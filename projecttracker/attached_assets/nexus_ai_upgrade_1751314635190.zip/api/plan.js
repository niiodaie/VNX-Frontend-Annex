const express = require('express');
const router = express.Router();
const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

router.post('/plan', async (req, res) => {
  const { description, tone = "concise", taskCount = 5 } = req.body;

  try {
    const messages = [{
      role: "system",
      content: "You are a project planning assistant. Create a clear milestone breakdown from user project descriptions. Focus on tasks and structure."
    }, {
      role: "user",
      content: `Project: ${description}. Tone: ${tone}. Tasks: ${taskCount}.`
    }];

    const response = await openai.createChatCompletion({
      model: "gpt-4o",
      messages,
      temperature: 0.6
    });

    const plan = JSON.parse(response.data.choices[0].message.content);
    res.json(plan);
  } catch (error) {
    console.error("GPT-4o Error:", error.message);
    res.status(500).json({ error: "Failed to generate plan." });
  }
});

module.exports = router;
