import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

export async function savePlanToSupabase(userId, planData) {
  const { data, error } = await supabase
    .from('plans')
    .insert([{ user_id: userId, ...planData }]);
  return { data, error };
}
