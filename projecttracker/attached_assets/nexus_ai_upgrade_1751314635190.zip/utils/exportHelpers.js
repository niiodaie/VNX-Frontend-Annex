export function exportToMarkdown(plan) {
  let md = `# ${plan.title}\n\n**Duration:** ${plan.duration}\n\n`;
  plan.milestones.forEach((m, i) => {
    md += `## Milestone ${i + 1}: ${m.title}\n`;
    md += `${m.description}\n\n`;
    m.tasks.forEach(t => {
      md += `- [ ] ${t}\n`;
    });
    md += '\n';
  });
  return md;
}

export function exportToJSON(plan) {
  return JSON.stringify(plan, null, 2);
}
