export function trackEvent(name, data = {}) {
  if (typeof window.gtag === 'function') {
    window.gtag('event', name, data);
  }
}
