import { useState } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '@/lib/supabaseClient'

export default function ResetPasswordConfirm() {
  const [newPassword, setNewPassword] = useState('')
  const [status, setStatus] = useState('')
  const router = useRouter()

  const handleReset = async () => {
    const hash = window.location.hash
    const accessToken = new URLSearchParams(hash.slice(1)).get('access_token')
    if (!accessToken) {
      setStatus('Invalid or expired reset link.')
      return
    }

    const { data, error } = await supabase.auth.updateUser({ password: newPassword })
    if (error) setStatus(error.message)
    else setStatus('Password successfully updated! You can now log in.')
  }

  return (
    <div className="container mx-auto text-center py-16">
      <h1 className="text-2xl font-bold mb-4">Reset Your Password</h1>
      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
        className="border p-2 rounded mb-4 w-full max-w-md"
      />
      <button onClick={handleReset} className="bg-blue-500 text-white px-4 py-2 rounded">Update Password</button>
      {status && <p className="mt-4 text-sm">{status}</p>}
    </div>
  )
}
