import React from 'react';

export default function PlanEditor({ plan, onUpdate }) {
  const updateTask = (milestoneIndex, taskIndex, newText) => {
    const newPlan = { ...plan };
    newPlan.milestones[milestoneIndex].tasks[taskIndex] = newText;
    onUpdate(newPlan);
  };

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">Edit Plan</h2>
      {plan.milestones.map((m, i) => (
        <div key={i} className="mb-4">
          <h3 className="font-bold mb-2">{m.title}</h3>
          {m.tasks.map((task, j) => (
            <input
              key={j}
              value={task}
              onChange={(e) => updateTask(i, j, e.target.value)}
              className="w-full border p-1 mb-1 rounded"
            />
          ))}
        </div>
      ))}
    </div>
  );
}
